# Api-test-gaviria
Backend test-comfenalco Node-json con mongodb

#Rutas
/signup es de tipo POST para registar
/signin es de tipo POST para hacer login
/profile Es de tipo GET para consultar profile

#Pasos
npm install
Instalar mongodb

Listo

